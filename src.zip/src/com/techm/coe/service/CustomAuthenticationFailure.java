package com.techm.coe.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.techm.coe.dao.ApplicationDao;

@Component
public class CustomAuthenticationFailure extends SimpleUrlAuthenticationFailureHandler {

	@Autowired
	ApplicationDao applicationDao;

	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {

		try {
			String uname = request.getParameter("username");
			if (null != uname)
				applicationDao.updateFailAttempts(uname);

			request.getSession().setAttribute("SPRING_SECURITY_LAST_EXCEPTION", exception);
			redirectStrategy.sendRedirect(request, response, "/login?error");
		} catch (Exception e) {
			e.printStackTrace();
			redirectStrategy.sendRedirect(request, response, "/login?error");
		}

	}

	public ApplicationDao getApplicationDao() {
		return applicationDao;
	}

	public void setApplicationDao(ApplicationDao aApplicationDao) {
		this.applicationDao = aApplicationDao;
	}

	public RedirectStrategy getRedirectStrategy() {
		return redirectStrategy;
	}

	public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
		this.redirectStrategy = redirectStrategy;
	}

}
