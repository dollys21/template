package com.techm.coe.service;

import java.util.List;

import com.techm.coe.beans.UsersBean;
import com.techm.coe.exception.COEException;
import com.techm.coe.model.COEUser;





public interface ApplicationService {

	
	void resetFailAttempts(String username) throws COEException;
	COEUser convertToUserEntity(UsersBean usersBean) throws COEException;
	
	List<String> getUserRoleNames();
	void captureUser(UsersBean usersBean) throws COEException;
	void getUserDetails(UsersBean userBean) throws COEException;
	//void getPaginatedUserList(UsersBean bean,ModelAndView mv);
}
