package com.techm.coe.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.techm.coe.dao.ApplicationDao;
import com.techm.coe.util.UserRoleType;



@Component
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private ApplicationDao applicationDao;
	
	
	@Override
	public UserDetails loadUserByUsername(final String username) throws UsernameNotFoundException {
		
		com.techm.coe.model.COEUser cOEUser  = applicationDao.findByUserName(username);
		if(null != cOEUser){
			List<GrantedAuthority> authorities = buildUserAuthority(cOEUser.getUserRole());
			return buildUserForAuthentication(cOEUser, authorities);
		}else{
			return null;
		}
		
	}

	private User buildUserForAuthentication(com.techm.coe.model.COEUser cOEUser, List<GrantedAuthority> authorities) {
		User user = new User(cOEUser.getUsername(), cOEUser.getPassword(), cOEUser.isEnabled(), true, true, !cOEUser.isAccountLocked(), authorities);
		return user;
	}

	private List<GrantedAuthority> buildUserAuthority(String userRole) {

		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();
		UserRoleType role = UserRoleType.valueOf(userRole);
		setAuths.add(new SimpleGrantedAuthority(role.toCompareString()));
		List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);
		Result.add(new SimpleGrantedAuthority(role.toCompareString()));
		return Result;
	}

	public ApplicationDao getApplicationDao() {
		return applicationDao;
	}

	public void setApplicationDao(ApplicationDao aApplicationDao) {
		this.applicationDao = aApplicationDao;
	}
	
}