package com.techm.coe.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.techm.coe.beans.UsersBean;
import com.techm.coe.common.AppConstants;
import com.techm.coe.dao.ApplicationDao;
import com.techm.coe.exception.COEException;
import com.techm.coe.model.COEUser;
import com.techm.coe.model.COEUserRole;

@Service
public class ApplicationServiceImpl implements ApplicationService {

	@Autowired
	private ApplicationDao applicationDao;

	@Override
	public void resetFailAttempts(String username) throws COEException {
		applicationDao.resetFailAttempts(username);

	}

	@Override
	public void captureUser(UsersBean usersBean) throws COEException {
		COEUser cOEUser = convertToUserEntity(usersBean);
		applicationDao.captureUser(cOEUser, usersBean.getUserType());
	}

	public COEUser convertToUserEntity(UsersBean usersBean) throws COEException {
		COEUser cOEUser = new COEUser();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		cOEUser.setUsername(usersBean.getUsername());
		cOEUser.setEmailId(usersBean.getEmailId());
		cOEUser.setEmpId(usersBean.getEmpId());
		cOEUser.setAccountLocked(usersBean.isAccountLocked());
		cOEUser.setEnabled(usersBean.isEnabled());
		cOEUser.setUserRole(usersBean.getUserRole());
		cOEUser.setName(usersBean.getName());

		COEUser user = applicationDao.findByUserName(cOEUser.getUsername());
		if (null == user) {
			cOEUser.setUserId(AppConstants.userIDSeq++);
			cOEUser.setPassword(encoder.encode(usersBean.getPassword()));
		} else {
			cOEUser.setUserId(user.getUserId());
			if (null == usersBean.getPassword()) {
				cOEUser.setPassword(user.getPassword());
			} else if (null != usersBean.getPassword()) {
				cOEUser.setPassword(encoder.encode(usersBean.getPassword()));
			}
		}
		if (!cOEUser.isAccountLocked()) {
			cOEUser.setFailedLoginAttempts(0);
		}
		return cOEUser;
	}

	public List<String> getUserRoleNames() {
		List<String> userRoleList = new ArrayList<String>();
		List<COEUserRole> userRoles = applicationDao.listUserRoles();
		if (null != userRoles && !userRoles.isEmpty()) {
			for (COEUserRole userRole : userRoles) {
				if (null != userRole && null != userRole.getRoleName())
					userRoleList.add(userRole.getRoleName());
			}
		}
		return userRoleList;
	}

	@Override
	public void getUserDetails(UsersBean userBean) throws COEException {
		COEUser user = applicationDao.findByUserName(userBean.getUsername());
		if (null != user) {
			userBean.setUsername(user.getUsername());
			userBean.setPassword(user.getPassword());
			userBean.setEmailId(user.getEmailId());
			userBean.setEmpId(user.getEmpId());
			userBean.setUserRole(user.getUserRole());
			userBean.setName(user.getUsername());
			userBean.setEnabled(user.isEnabled());
			userBean.setAccountLocked(user.isAccountLocked());
		}
	}

}
