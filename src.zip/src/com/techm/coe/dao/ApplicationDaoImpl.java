package com.techm.coe.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.techm.coe.common.AppConstants;
import com.techm.coe.model.COEUser;
import com.techm.coe.model.COEUserRole;

@Repository("ApplicationDao")
public class ApplicationDaoImpl implements ApplicationDao {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public COEUser findByUserName(String username) {

		List<COEUser> users = new ArrayList<COEUser>();

		System.out.println(users.toString());

		users = sessionFactory.getCurrentSession().createQuery("from COEUser where username=?").setParameter(0, username).list();

		if (users.size() > 0) {
			return users.get(0);
		} else {
			return null;
		}

	}

	@Transactional
	public void captureUser(COEUser cOEUser, String type) {

		if (null != type && type.equalsIgnoreCase(AppConstants.USER_TYPE_NEW)) {
			sessionFactory.getCurrentSession().save(cOEUser);
		} else if (null != type && type.equalsIgnoreCase(AppConstants.USER_TYPE_EXISTING)) {
			sessionFactory.getCurrentSession().update(cOEUser);
		}

	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<COEUser> listUser() {

		return (List<COEUser>) getSessionFactory().getCurrentSession().createQuery("from coe_users").list();
		

	}

	@Override
	@Transactional
	public void updateFailAttempts(String username) {

		COEUser user = findByUserName(username);
		if (null != user) {
			if (user.getFailedLoginAttempts() + 1 >= AppConstants.MAX_LOGIN_ATTEMPTS && !user.isAccountLocked()) {
				user.setAccountLocked(true);
				user.setFailedLoginAttempts(0);
			} else {
				user.setFailedLoginAttempts(user.getFailedLoginAttempts() + 1);
			}
			sessionFactory.getCurrentSession().merge(user);
		}
	}

	@Override
	@Transactional
	public void resetFailAttempts(String username) {

		COEUser user = findByUserName(username);
		if (null != user) {
			user.setFailedLoginAttempts(0);
			user.setAccountLocked(false);
			sessionFactory.getCurrentSession().merge(user);
		}
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<COEUserRole> listUserRoles() {
		return (List<COEUserRole>) getSessionFactory().getCurrentSession().createQuery("from coe_user_roles").list();
		/*
		 * sessionFactory.getCurrentSession().createCriteria(cOEUser.class).list();
		 */

	}

}