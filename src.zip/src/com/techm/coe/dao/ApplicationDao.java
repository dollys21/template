package com.techm.coe.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.techm.coe.model.COEUser;
import com.techm.coe.model.COEUserRole;

@Repository
public interface ApplicationDao {

	COEUser findByUserName(String username);

	public void captureUser(COEUser cOEUser, String type);

	public List<COEUser> listUser();

	void updateFailAttempts(String username);

	void resetFailAttempts(String username);

	List<COEUserRole> listUserRoles();

}