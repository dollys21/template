package com.techm.coe.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.techm.coe.beans.UsersBean;
import com.techm.coe.exception.COEException;
import com.techm.coe.model.COEUser;
import com.techm.coe.service.ApplicationService;

@Controller
public class UserController {

	@Autowired
	private ApplicationService applicationService;

	@RequestMapping(value = "viewUser", method = RequestMethod.GET)
	public ModelAndView captureUser(@ModelAttribute("cOEUser") UsersBean bean, BindingResult result)
			throws COEException {

		ModelAndView mv = new ModelAndView();
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("roles", applicationService.getUserRoleNames());
		mv.addObject("viewUserList", model);
		return mv;
	}
	
	 /*private List<UsersBean> prepareListofBean(List<COEUser> coeuser){
		  List<UsersBean> beans = null;
		  if(coeuser != null && !coeuser.isEmpty()){
		   beans = new ArrayList<UsersBean>();
		   UsersBean bean = null;
		   for(COEUser coeUser : coeuser){
		    bean = new UsersBean();
		    bean.setUsername(coeUser.getUsername());
		    bean.setPassword(bean.getPassword());
		    bean.setEmailId(bean.getEmailId());
		    
		    beans.add(bean);
		   }
		  }
		return beans;
	 }*/
}

