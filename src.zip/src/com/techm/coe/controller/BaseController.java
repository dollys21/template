package com.techm.coe.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.techm.coe.exception.COEException;


@Controller
public class BaseController {

	
	@RequestMapping(value = { "/","/home*" }, method = RequestMethod.GET)
	public ModelAndView getDefaultPage() throws Exception {
		ModelAndView model = new ModelAndView();
		model.setViewName("home");
		//throw new Exception("This is manually generated exception.");
		return model;
	}
	
	@RequestMapping(value = "form_validation", method = RequestMethod.GET)
	public ModelAndView formValidationPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("form_validation");
		return model;
	}
	
	@RequestMapping(value = "form", method = RequestMethod.GET)
	public ModelAndView formPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("form");
		return model;
	}
	
	@RequestMapping(value = "tables_dynamic", method = RequestMethod.GET)
	public ModelAndView tablesDynamicPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("viewUserList");
		return model;
	}
	
	@RequestMapping(value = "mainPage", method = RequestMethod.GET)
	public ModelAndView mainPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("main_page");
		return model;
	}


	@ExceptionHandler(COEException.class)
	public ModelAndView handleAllException(COEException ex) {
	
		ModelAndView model = new ModelAndView("error");
		model.addObject("error_message", ex.getMessage());
		return model;
	}
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleAllException(Exception ex) {
	
		ModelAndView model = new ModelAndView("error");
		model.addObject("error_message", ex.getMessage());
		return model;
	}

}
