package com.techm.coe.common;

public class AppConstants {

	public static final String MANAGER = "Manager";
	public static final String TEAM_MEMBER = "TeamMember";
	public static final String MEMBER = "Member";
	public static final String LEADER = "Leader";
	public static final String USER_TYPE_NEW = "New";
	public static final String USER_TYPE_EXISTING = "Existing";
	public static long userIDSeq = 10;
	public static int MAX_LOGIN_ATTEMPTS = 3;
	public static final int RECORDS_PER_PAGE = 10;
	public static int FIRST_RECORD_STARTS_WITH = 0;
	public static int SIZE_OF_LIST = 0;

}

