package com.techm.coe.aspect;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.techm.coe.util.LogUtil;

import java.time.LocalDateTime;
import org.aspectj.lang.*;
import org.aspectj.lang.annotation.*;


@Aspect
@Component
public class LoggerAdvice {

	private static final Logger logger = LoggerFactory.getLogger(LoggerAdvice.class);
	
    @Before("execution(* com.techm.coe..*(..))")
    public void log(JoinPoint point) {
    	LogUtil.debug(logger, LocalDateTime.now() + "   Method : "+point.getSignature().getName(), null);
 
    }
}

