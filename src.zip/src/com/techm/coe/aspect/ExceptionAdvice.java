package com.techm.coe.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class ExceptionAdvice{
	
	//@Pointcut("execution(* com.techm.coe..*(..))")
	@Pointcut("within(com.techm.coe.*)")
	public void exceptionHandlingPointcut() {}
	
	@Around("exceptionHandlingPointcut()")
	public void exceptionAdvice(ProceedingJoinPoint joinPoint) throws Throwable {

		try {
			joinPoint.proceed();
		} catch (Throwable ex) {
			throw ex;
		}
	}
	
}