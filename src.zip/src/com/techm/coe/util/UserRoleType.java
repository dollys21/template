package com.techm.coe.util;

public enum UserRoleType {
	ROLE_ADMIN("ROLE_ADMIN"),
	ROLE_MANAGER("ROLE_MANAGER");
	
	private String name;

	UserRoleType(String value) {
        this.name = value;
    }

    public String toCompareString() {
        return name.toUpperCase(); 
    }
    
    public static UserRoleType getValue(String value) {
        for(UserRoleType v : values())
            if(v.toString().equalsIgnoreCase(value)) return v;
        throw new IllegalArgumentException();
    }

}
