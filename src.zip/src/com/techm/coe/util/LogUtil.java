package com.techm.coe.util;

import org.slf4j.Logger;

public class LogUtil {
	
	public static void debug(Logger logger, String msg, Object obj) {
		if (logger.isDebugEnabled()) {
			logger.debug(msg, obj);
		}
	}
	
	public static void debug(Logger logger, String msg, Object[] obj) {
		if (logger.isDebugEnabled()) {
			logger.debug(msg, obj);
		}
	}
	
	public static void warn(Logger logger, String msg, Object obj) {
		if (logger.isWarnEnabled()) {
			logger.warn(msg, obj);
		}
	}
	
	public static void warn(Logger logger, String msg, Object[] obj) {
		if (logger.isWarnEnabled()) {
			logger.warn(msg, obj);
		}
	}
	
	public static void error(Logger logger, String msg, Object obj) {
		if (logger.isErrorEnabled()) {
			logger.error(msg, obj);
		}
	}
	
	public static void error(Logger logger, String msg, Object[] obj) {
		if (logger.isErrorEnabled()) {
			logger.error(msg, obj);
		}
	}

}
