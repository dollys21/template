package com.techm.coet.login;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.techm.coet.util.AppConstants;
import com.techm.coet.util.LogUtil;

@Repository("ApplicationDao")
public class ApplicationDaoImpl implements ApplicationDao {

	@Autowired
	private SessionFactory sessionFactory;

	private static final Logger logger = LoggerFactory.getLogger(ApplicationDaoImpl.class);

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public LPUser findByUserName(String username) {

		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		List<LPUser> users = new ArrayList<LPUser>();

		System.out.println(users.toString());

		users = sessionFactory.getCurrentSession().createQuery("from LPUser where username=?").setParameter(0, username)
				.list();

		if (users.size() > 0) {
			return users.get(0);
		} else {
			return null;
		}

	}

	@Transactional
	public void captureUser(LPUser lpuser, String type) {

		LogUtil.error(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);

		if (null != type && type.equalsIgnoreCase(AppConstants.USER_TYPE_NEW)) {
			sessionFactory.getCurrentSession().save(lpuser);
		} else if (null != type && type.equalsIgnoreCase(AppConstants.USER_TYPE_EXISTING)) {
			sessionFactory.getCurrentSession().update(lpuser);
		}

	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<LPUser> listUser() {

		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);

		return (List<LPUser>) getSessionFactory().getCurrentSession().createQuery("from LPUser").list();
		/*
		 * sessionFactory.getCurrentSession().createCriteria(LPUser.class).list(
		 * );
		 */

	}

	@Override
	@Transactional
	public void updateFailAttempts(String username) {

		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);

		LPUser user = findByUserName(username);
		if (null != user) {
			if (user.getFailedLoginAttempts() + 1 >= AppConstants.MAX_LOGIN_ATTEMPTS && !user.isAccountLocked()) {
				user.setAccountLocked(true);
				user.setFailedLoginAttempts(0);
			} else {
				user.setFailedLoginAttempts(user.getFailedLoginAttempts() + 1);
			}
			sessionFactory.getCurrentSession().merge(user);
		}
	}

	@Override
	@Transactional
	public void resetFailAttempts(String username) {

		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);

		LPUser user = findByUserName(username);
		if (null != user) {
			user.setFailedLoginAttempts(0);
			user.setAccountLocked(false);
			sessionFactory.getCurrentSession().merge(user);
		}
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<LPUserRole> listUserRoles() {
		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		return (List<LPUserRole>) getSessionFactory().getCurrentSession().createQuery("from LPUserRole").list();
		/*
		 * sessionFactory.getCurrentSession().createCriteria(LPUser.class).list(
		 * );
		 */

	}

}