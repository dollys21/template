package com.techm.coet.login;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository
public interface ApplicationDao {

	LPUser findByUserName(String username);

	public void captureUser(LPUser lpuser, String type);

	public List<LPUser> listUser();

	void updateFailAttempts(String username);

	void resetFailAttempts(String username);

	List<LPUserRole> listUserRoles();

}