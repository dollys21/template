package com.techm.coet.login;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "lp_users")
public class LPUser implements Serializable,Comparable<LPUser>{
	
	private static final long serialVersionUID = 1134370660137895733L;

	
	@Column(name="user_id")
	@SequenceGenerator(name = "seq", sequenceName = "LP_USER_ID_SEQ")
    @GeneratedValue(generator = "seq")
	private long userId;
	
	@Id
	@Column(name = "username", unique = true, nullable = false, length = 45)
	private String username;
	
	@Column(name = "password", nullable = false, length = 60)
	private String password;
	
	@Column(name="email_id",nullable = false, length = 150)
	private String emailId;
	
	@Column(name="employee_id",nullable = false)
	private Integer empId;

	@Column(name = "is_active", nullable = false)
	private boolean enabled;

	@Column(name = "role_name", nullable = false)
	private String userRole;
	
	@Column(name = "FAILED_LOGIN_ATTEMPTS")
	private int failedLoginAttempts;
	
	@Column(name="ACCOUNT_LOCKED")
	private boolean accountLocked;
	
	@Column(name="name")
	private String name;
	
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public int getFailedLoginAttempts() {
		return failedLoginAttempts;
	}

	public void setFailedLoginAttempts(int failedLoginAttempts) {
		this.failedLoginAttempts = failedLoginAttempts;
	}
	
	public boolean isAccountLocked() {
		return accountLocked;
	}

	public void setAccountLocked(boolean accountLocked) {
		this.accountLocked = accountLocked;
	}
	
	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "LPUser [userId=" + userId + ", username=" + username + ", password=" + password + ", emailId=" + emailId
				+ ", contactNumber=" + empId + ", enabled=" + enabled + ", userRole=" + userRole + "]";
	}

	@Override
	public int compareTo(LPUser user) {
		return this.getUsername().toUpperCase().compareTo(user.getUsername().toUpperCase());
	}

}
