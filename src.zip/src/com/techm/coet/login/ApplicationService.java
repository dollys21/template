package com.techm.coet.login;

import java.util.List;

import org.springframework.web.servlet.ModelAndView;

import com.techm.coet.util.LPException;



public interface ApplicationService {

	
	void resetFailAttempts(String username) throws LPException;
	LPUser convertToUserEntity(UsersBean usersBean) throws LPException;
	
	List<String> getUserRoleNames();
	void captureUser(UsersBean usersBean) throws LPException;
	void getUserDetails(UsersBean userBean) throws LPException;
	//void getPaginatedUserList(UsersBean bean,ModelAndView mv);
}
