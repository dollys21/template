package com.techm.coet.login;

public class UsersBean {

	private String username;
	private String password;
	private String emailId;
	private Integer empId;
	private boolean enabled;
	private Integer failedLoginAttempts;
	private boolean accountLocked;
	private String userRole;
	private String name;
	private String userType;
	private int page;
	private boolean paginationCall;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public Integer getFailedLoginAttempts() {
		return failedLoginAttempts;
	}
	public void setFailedLoginAttempts(Integer failedLoginAttempts) {
		this.failedLoginAttempts = failedLoginAttempts;
	}
	public boolean isAccountLocked() {
		return accountLocked;
	}
	public void setAccountLocked(boolean accountLocked) {
		this.accountLocked = accountLocked;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	
	public boolean isPaginationCall() {
		return paginationCall;
	}
	public void setPaginationCall(boolean paginationCall) {
		this.paginationCall = paginationCall;
	}
	
	@Override
	public String toString() {
		return "UsersBean [username=" + username + ", password=" + password + ", emailId=" + emailId + ", empId="
				+ empId + ", enabled=" + enabled + ", failedLoginAttempts=" + failedLoginAttempts + ", accountLocked="
				+ accountLocked + ", userRole=" + userRole + ", name=" + name + ", userType=" + userType + "]";
	}
	
}
