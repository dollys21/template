package com.techm.coet.login;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.techm.coet.util.AppConstants;
import com.techm.coet.util.LPException;



@Service
public class ApplicationServiceImpl implements ApplicationService {

	@Autowired
	private ApplicationDao applicationDao;

	private static final Logger logger = LoggerFactory.getLogger(ApplicationDaoImpl.class);

	
	@Override
	public void resetFailAttempts(String username) throws LPException{
		applicationDao.resetFailAttempts(username);

	}
	
	@Override
	public void captureUser(UsersBean usersBean) throws LPException{
		LPUser lpUser = convertToUserEntity(usersBean);
		applicationDao.captureUser(lpUser, usersBean.getUserType());
	}
	
	public LPUser convertToUserEntity(UsersBean usersBean) throws LPException{
		LPUser lpuser =  new LPUser();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		lpuser.setUsername(usersBean.getUsername());
		lpuser.setEmailId(usersBean.getEmailId());
		lpuser.setEmpId(usersBean.getEmpId());
		lpuser.setAccountLocked(usersBean.isAccountLocked());
		lpuser.setEnabled(usersBean.isEnabled());
		lpuser.setUserRole(usersBean.getUserRole());
		lpuser.setName(usersBean.getName());
		
		LPUser user = applicationDao.findByUserName(lpuser.getUsername());
		if(null == user){
			lpuser.setUserId(AppConstants.userIDSeq++);
			lpuser.setPassword(encoder.encode(usersBean.getPassword()));
		}else{
			lpuser.setUserId(user.getUserId());
			if(null ==usersBean.getPassword()){
				lpuser.setPassword(user.getPassword());
			}else if(null!= usersBean.getPassword()){
				lpuser.setPassword(encoder.encode(usersBean.getPassword()));
			}
		}
		if(!lpuser.isAccountLocked()){
			lpuser.setFailedLoginAttempts(0);
		}
		return lpuser;
	}
	
	public List<String> getUserRoleNames(){
		List<String> userRoleList = new ArrayList<String>();
		List<LPUserRole> userRoles = applicationDao.listUserRoles();
		if(null != userRoles && !userRoles.isEmpty()){
			for(LPUserRole userRole:userRoles){
				if(null != userRole && null != userRole.getRoleName())
					userRoleList.add(userRole.getRoleName());
			}
		}
		return userRoleList;
	}
	
	
	@Override
	public void getUserDetails(UsersBean userBean) throws LPException{
		LPUser user = applicationDao.findByUserName(userBean.getUsername());
		if(null != user){
			userBean.setUsername(user.getUsername());
			userBean.setPassword(user.getPassword());
			userBean.setEmailId(user.getEmailId());
			userBean.setEmpId(user.getEmpId());
			userBean.setUserRole(user.getUserRole());
			userBean.setName(user.getUsername());
			userBean.setEnabled(user.isEnabled());
			userBean.setAccountLocked(user.isAccountLocked());
		}
	}
	
	
	
	/*@SuppressWarnings("rawtypes")
	private void getPaginatedList(ModelAndView mv,PagedListHolder pagedListHolder,int pageSize,int page,String parameterName){
		pagedListHolder.setPageSize(pageSize);
		mv.addObject("maxPages", pagedListHolder.getPageCount());
		
		if(page < 1 || page > pagedListHolder.getPageCount()){
			pagedListHolder.setPage(0);
			mv.addObject("page", 0);
			mv.addObject(parameterName, pagedListHolder.getPageList());
		}
		else if(page <= pagedListHolder.getPageCount()) {
			pagedListHolder.setPage(page);
			mv.addObject("page", page);
			mv.addObject(parameterName, pagedListHolder.getPageList());
		}
	}*/
}
