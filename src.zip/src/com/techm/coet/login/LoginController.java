package com.techm.coet.login;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.techm.coet.security.CustomUserDetailsService;
import com.techm.coet.util.LPException;
import com.techm.coet.util.LogUtil;
import com.techm.coet.util.UserRoleType;

@Controller
public class LoginController {

	@Autowired
	CustomUserDetailsService customUserDetailsService;

	@Autowired
	private ApplicationService applicationService;

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

	Session session = null;
	Transaction tx = null;

	@Autowired
	BCryptPasswordEncoder encoder;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "inputName", required = false) String username,
			@RequestParam(value = "logout", required = false) String logout, HttpServletRequest request) {

		ModelAndView model = new ModelAndView();
		if (error != null && null != error.trim()) {
			model.addObject("error", getErrorMessage(request, "SPRING_SECURITY_LAST_EXCEPTION"));

		}

		if (logout != null) {
			model.addObject("msg", "You've been logged out successfully.");
		}
		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		model.setViewName("login");

		return model;

	}

	@RequestMapping(value = "/loginfrag*")
	public ModelAndView redirectLogin() {

		ModelAndView mv = new ModelAndView();
		// String jspName = new String();
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		// reset user login attempts before contnuing busniess flow.
		try {
			applicationService.resetFailAttempts(userDetails.getUsername());
		} catch (LPException e) {
			LogUtil.error(logger,
					LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(),
					e);
			e.printStackTrace();
			mv.addObject("error", "Could not login. Please contact system administrator.");
		} catch (Exception e) {
			LogUtil.error(logger,
					LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(),
					e);
			e.printStackTrace();
			mv.addObject("error", "A general error has occurred.Please contact system administrator.");
		}

		if (userDetails.getAuthorities().contains(new SimpleGrantedAuthority(UserRoleType.MANAGER.toString()))) {
			mv.setViewName("dashboard");

		} else if (userDetails.getAuthorities().contains(new SimpleGrantedAuthority(UserRoleType.ADMIN.toString()))) {

			mv.setViewName("tables_dynamic");
		}
		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		return mv;

	}

	// customize the error message
	public String getErrorMessage(HttpServletRequest request, String key) {

		Exception exception = (Exception) request.getSession().getAttribute(key);

		String error = "";
		if (exception instanceof BadCredentialsException) {
			error = "Invalid username and password!";
		} else if (exception instanceof AuthenticationServiceException) {
			error = "Invalid login credentials";
		} else if (exception instanceof LockedException || exception instanceof DisabledException) {
			error = exception.getMessage();
		} else {
			error = "Could not login. Please contact system administrator.";
		}
		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		return error;
	}

}