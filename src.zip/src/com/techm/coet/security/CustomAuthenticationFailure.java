package com.techm.coet.security;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.techm.coet.login.ApplicationDao;
import com.techm.coet.util.LogUtil;


@Component
public class CustomAuthenticationFailure extends SimpleUrlAuthenticationFailureHandler {
	
	@Autowired
	ApplicationDao applicationDao;
	
	private static final Logger logger = LoggerFactory.getLogger(CustomAuthenticationFailure.class);
	
	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
	
	@Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {    
		
		try{
			String uname = request.getParameter("username");
			if(null != uname)
				applicationDao.updateFailAttempts(uname);
		    
			request.getSession().setAttribute("SPRING_SECURITY_LAST_EXCEPTION", exception);
			redirectStrategy.sendRedirect(request, response, "/login?error");
		}catch(Exception e){
			LogUtil.error(logger, LocalDateTime.now() + "   Method : "+Thread.currentThread().getStackTrace()[1].getMethodName(), e);
			e.printStackTrace();
			redirectStrategy.sendRedirect(request, response, "/login?error");
		}
		
	}
	
	public ApplicationDao getApplicationDao() {
		return applicationDao;
	}

	public void setApplicationDao(ApplicationDao aApplicationDao) {
		this.applicationDao = aApplicationDao;
	}

	public RedirectStrategy getRedirectStrategy() {
		return redirectStrategy;
	}

	public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
		this.redirectStrategy = redirectStrategy;
	}
	
	
}
