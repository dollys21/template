package com.techm.coet.security;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.techm.coet.login.ApplicationDao;
import com.techm.coet.login.LPUser;
import com.techm.coet.util.LogUtil;
import com.techm.coet.util.UserRoleType;



@Component
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private ApplicationDao applicationDao;
	
	private static final Logger logger = LoggerFactory.getLogger(CustomUserDetailsService.class);
	
	@Override
	public UserDetails loadUserByUsername(final String username) throws UsernameNotFoundException {
		
		LogUtil.debug(logger, LocalDateTime.now() + "   Method : "+Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		
		LPUser lpUser  = applicationDao.findByUserName(username);
		if(null != lpUser){
			List<GrantedAuthority> authorities = buildUserAuthority(lpUser.getUserRole());
			return buildUserForAuthentication(lpUser, authorities);
		}else{
			return null;
		}
		
	}

	private User buildUserForAuthentication(LPUser lpUser, List<GrantedAuthority> authorities) {
		
		LogUtil.debug(logger, LocalDateTime.now() + "   Method : "+Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		User user = new User(lpUser.getUsername(), lpUser.getPassword(), lpUser.isEnabled(), true, true, !lpUser.isAccountLocked(), authorities);
		return user;
	}

	private List<GrantedAuthority> buildUserAuthority(String userRole) {
		
		LogUtil.debug(logger, LocalDateTime.now() + "   Method : "+Thread.currentThread().getStackTrace()[1].getMethodName(), null);

		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();
		UserRoleType role = UserRoleType.valueOf(userRole);
		setAuths.add(new SimpleGrantedAuthority(role.toCompareString()));
		List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);
		Result.add(new SimpleGrantedAuthority(role.toCompareString()));
		return Result;
	}

	public ApplicationDao getApplicationDao() {
		return applicationDao;
	}

	public void setApplicationDao(ApplicationDao aApplicationDao) {
		this.applicationDao = aApplicationDao;
	}
	
}