package com.techm.coet.common;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.techm.coet.util.LogUtil;

@Controller
public class BaseController {

	private static final Logger logger = LoggerFactory.getLogger(BaseController.class);

	@RequestMapping(value = { "/", "/home*" }, method = RequestMethod.GET)
	public ModelAndView defaultPage() {
		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		ModelAndView model = new ModelAndView();
		model.setViewName("dashboard");
		return model;

	}

	

	// customize the error message
	public String getErrorMessage(HttpServletRequest request, String key) {

		Exception exception = (Exception) request.getSession().getAttribute(key);

		String error = "";
		if (exception instanceof BadCredentialsException) {
			error = "Invalid username and password!";
		} else if (exception instanceof AuthenticationServiceException) {
			error = "Invalid login credentials";
		} else if (exception instanceof LockedException || exception instanceof DisabledException) {
			error = exception.getMessage();
		} else {
			error = "Could not login. Please contact system administrator.";
		}
		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		return error;
	}

}
