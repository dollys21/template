package com.techm.coet.common;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.techm.coet.util.LogUtil;

@Controller
public class ErrorPageController {

	private static final Logger logger = LoggerFactory.getLogger(BaseController.class);

	// for 403 access denied page
		@RequestMapping(value = "/403", method = RequestMethod.GET)
		public ModelAndView accesssDenied() {

			ModelAndView model = new ModelAndView();

			// check if user is login
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			if (!(auth instanceof AnonymousAuthenticationToken)) {
				UserDetails userDetail = (UserDetails) auth.getPrincipal();
				System.out.println(userDetail);

				model.addObject("username", userDetail.getUsername());

			}
			LogUtil.debug(logger,
					LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
			model.setViewName("page_403");
			return model;

		}

	// for 404 webpage Not Found
	@RequestMapping(value = "/404", method = RequestMethod.GET)
	public ModelAndView pageNotFound() {

		ModelAndView model = new ModelAndView();
		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		model.setViewName("page_404");
		return model;

	}

	// for 500 Internal server error page
	@RequestMapping(value = "/500", method = RequestMethod.GET)
	public ModelAndView internalServerError() {

		ModelAndView model = new ModelAndView();
		LogUtil.debug(logger,
				LocalDateTime.now() + "   Method : " + Thread.currentThread().getStackTrace()[1].getMethodName(), null);
		model.setViewName("page_500");
		return model;

	}
}
