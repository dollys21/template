package com.techm.coet.util;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;

import com.techm.coet.login.LoginController;

public class ErrorMessageUtil {
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	
	// customize the error message
		public String getErrorMessage(HttpServletRequest request, String key) {

			Exception exception = (Exception) request.getSession().getAttribute(key);

			String error = "";
			if (exception instanceof BadCredentialsException) {
				error = "Invalid username and password!";
			}else if (exception instanceof AuthenticationServiceException){
				error = "Invalid login credentials";
			}else if(exception instanceof LockedException || exception instanceof DisabledException){
				error = exception.getMessage();
			}else{
				error = "Could not login. Please contact system administrator.";
			}
			LogUtil.debug(logger, LocalDateTime.now() + "   Method : "+Thread.currentThread().getStackTrace()[1].getMethodName(), null);
			return error;
		}


}
